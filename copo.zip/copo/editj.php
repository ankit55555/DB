<!DOCTYPE html>
<head>
	
	<link rel="stylesheet" href="./form1.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> 
   <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
</head>

<?php error_reporting(1);?>

<body>
<form action=entryedit.php method=post>
	<div class=wrapper>
		<div class="title">
        Edit Justification
      </div>

      <div class="form">
      	<div class="inputfield">
          <label>Course code:</label><input type="text" maxlength="8"  id="course_cd" name="course_cd" required><br><br>
        </div>
        <div class="inputfield">
          <label for="cay">Academic Year:</label>
        <div class="custom_select">
            <select name="cay" id="cay" required>
              <option value="" disabled>--</option>
              <option value="13">2013-2014</option>
              <option value="14">2014-2015</option>
              <option value="15">2015-2016</option>
              <option value="16">2016-2017</option>
              <option value="17">2017-2018</option>
              <option value="18">2018-2019</option>
              <option value="19">2019-2020</option>
              <option value="20">2020-2021</option>
              <option value="17">2021-2022</option>
              <option value="18">2022-2023</option>
             </select><br><br>
          </div>
        </div>
        <div class="inputfield">
          <input type="submit" name="editj" value="Edit" class="btn">
        </div>
      </div>
	</div>
</form>	

</body>

</html>