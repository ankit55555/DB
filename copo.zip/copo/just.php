<html>
<head>
			<?php


		include 'conn.php';



	    $editj=$_POST['editj'];
		$course_cd=$_POST['course_cd'];
		$cay=$_POST["cay"];
		$jc1=serialize($_POST['jc1']);
   		$jc2=serialize($_POST['jc2']);
    	$jc3=serialize($_POST['jc3']);
    	$jc4=serialize($_POST['jc4']);
    	$uid=$course_cd.$cay;








        if($editj=='Edit'){
           $q="UPDATE justify SET uid='$uid', course_cd='$course_cd', jc1='$jc1', jc2='$jc2' , jc3='$jc3' ,jc4='$jc4' WHERE uid='$uid';";
        }else{
           $q="INSERT into justify (uid,course_cd,jc1,jc2,jc3,jc4) values ('$uid','$course_cd','$jc1','$jc2','$jc3','$jc4');";
        }

        $e=mysqli_query($link,$q);

if(is_null($e)){
             echo 'Could not enter data: ';
         }
    else{


        header("Location:form.php");

       }


 ?>
</head>

<body></body>

</html>
