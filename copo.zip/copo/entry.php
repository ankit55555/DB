<html>
<head>
    <link rel="stylesheet" href="./form1.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
 <?php
 error_reporting(1);
    include "conn.php";

    $course_cd=htmlspecialchars($_POST['course_cd']);
    $editj=$_POST['editj'];
    $course_nm=htmlspecialchars($_POST['course_nm']);
    $dept=htmlspecialchars($_POST['dept']);
    $sem=htmlspecialchars($_POST['sem']);
    $cay=htmlspecialchars($_POST['cay']);
    $po1=serialize($_POST['po1']);
    $po2=serialize($_POST['po2']);
    $po3=serialize($_POST['po3']);
    $po4=serialize($_POST['po4']);
    $po5=serialize($_POST['po5']);
    $po6=serialize($_POST['po6']);
    $po7=serialize($_POST['po7']);
    $po8=serialize($_POST['po8']);
    $po9=serialize($_POST['po9']);
    $po10=serialize($_POST['po10']);
    $po11=serialize($_POST['po11']);
    $po12=serialize($_POST['po12']);
    $pso1=serialize($_POST['pso1']);
    $pso2=serialize($_POST['pso2']);
    $pso3=serialize($_POST['pso3']);
    $pso4=serialize($_POST['pso4']);
    $co1=htmlspecialchars($_POST["co1"]);
   $co2=htmlspecialchars($_POST["co2"]);
   $co3=htmlspecialchars($_POST["co3"]);
   $co4=htmlspecialchars($_POST["co4"]);
   
    $uid=$course_cd.$cay;
    $p1=$_POST['po1'];
    $p2=$_POST['po2'];
    $p3=$_POST['po3'];
    $p4=$_POST['po4'];
    $p5=$_POST['po5'];
    $p6=$_POST['po6'];
    $p7=$_POST['po7'];
    $p8=$_POST['po8'];
    $p9=$_POST['po9'];
    $p10=$_POST['po10'];
    $p11=$_POST['po11'];
    $p12=$_POST['po12'];
    $ps1=$_POST['pso1'];
    $ps2=$_POST['pso2'];
    $ps3=$_POST['pso3'];
    $ps4=$_POST['pso4'];



    $query="insert into copo (uid,course_cd,course_nm,dept,sem,cay,po1,po2,po3,po4,po5,po6,po7,po8,po9,po10,po11,po12,pso1,pso2,pso3,pso4) values ('$uid','$course_cd','$course_nm','$dept','$sem','$cay','$po1','$po2','$po3','$po4','$po5','$po6','$po7','$po8','$po9','$po10','$po11','$po12','$pso1','$pso2','$pso3','$pso4');";

   $entry=mysqli_query($link,$query);


  


    
  if(is_null($entry)){
            echo 'Could not enter data: ';
         }
  // else{ 

      
    //   header("Location: http://localhost/Project/form.php");
          
      //} 

  


 ?> 





<!-- Page Content -->

<div class=wrapp>
<div class="w3-container w3-teal">
  <h1>Justification mapping</h1>
</div>
<form action="just.php" method="post">
<table class="w3-table w3-bordered">
 <tr>
    <th>CO</th>
    <th style="width:150px">PO</th>
    <th style="width:150px">Level of mapping</th>
    <th>Justification</th>
 <tr>
     <td rowspan=16 >CO1</td>
     <tr>
    <td>PO1</td>
    <th style="height:37px;"><?php echo $p1[0];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc1[] type=text value=></td>
</tr>
<tr>
    <td>PO2</td>
    <th style="height:37px;"><?php echo $p2[0];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc1[] type=text value=></td>
</tr>
<tr>
    <td>PO3</td>
    <th style="height:37px;"><?php echo $p3[0];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc1[] type=text value=></td>
</tr>
<tr>
    <td>PO4</td>
    <th style="height:37px;"><?php echo $p4[0];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc1[] type=text value=></td>
</tr>
<tr>
    <td>PO5</td>
    <th style="height:37px;"><?php echo $p5[0];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc1[] type=text value=></td>
</tr>
<tr>
    <td>PO6</td>
    <th style="height:37px;"><?php echo $p6[0];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc1[] type=text value=></td>
</tr>
<tr>
    <td>PO7</td>
    <th style="height:37px;"><?php echo $p7[0];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc1[] type=text value=></td>
</tr>
<tr>
    <td>PO8</td>
    <th style="height:37px;"><?php echo $p8[0];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc1[] type=text value=></td>
</tr>
<tr>
    <td>PO9</td>
    <th style="height:37px;"><?php echo $p9[0];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc1[] type=text value=></td>
</tr>
<tr>
    <td>PO10</td>
    <th style="height:37px;"><?php echo $p10[0];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc1[] type=text value=></td>
</tr>
<tr>
    <td>PO11</td>
    <th style="height:37px;"><?php echo $p11[0];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc1[] type=text value=></td>
</tr>
<tr>
    <td>PO12</td>
    <th style="height:37px;"><?php echo $p12[0];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc1[] type=text value=></td>
</tr>
<tr>
    <td>PSO1</td>
    <th style="height:37px;"><?php echo $ps1[0];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc1[] type=text value=></td>
</tr>
<tr>
    <td>PSO2</td>
    <th style="height:37px;"><?php echo $ps2[0];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc1[] type=text value=></td>
</tr>
<tr>
    <td>PSO3</td>
    <th style="height:37px;"><?php echo $ps3[0];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc1[] type=text value=></td>
</tr>
<tr>
     <td rowspan=16 >CO2</td>
     <tr>
    <td>PO1</td>
    <th style="height:37px;"><?php echo $p1[1];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc2[] type=text value=></td>
</tr>
<tr>
    <td>PO2</td>
    <th style="height:37px;"><?php echo $p2[1];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc2[] type=text value=></td>
</tr>
<tr>
    <td>PO3</td>
    <th style="height:37px;"><?php echo $p3[1];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc2[] type=text value=></td>
</tr>
<tr>
    <td>PO4</td>
    <th style="height:37px;"><?php echo $p4[1];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc2[] type=text value=></td>
</tr>
<tr>
    <td>PO5</td>
    <th style="height:37px;"><?php echo $p5[1];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc2[] type=text value=></td>
</tr>
<tr>
    <td>PO6</td>
    <th style="height:37px;"><?php echo $p6[1];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc2[] type=text value=></td>
</tr>
<tr>
    <td>PO7</td>
    <th style="height:37px;"><?php echo $p7[1];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc2[] type=text value=></td>
</tr>
<tr>
    <td>PO8</td>
    <th style="height:37px;"><?php echo $p8[1];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc2[] type=text value=></td>
</tr>
<tr>
    <td>PO9</td>
    <th style="height:37px;"><?php echo $p9[1];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc2[] type=text value=></td>
</tr>
<tr>
    <td>PO10</td>
    <th style="height:37px;"><?php echo $p10[1];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc2[] type=text value=></td>
</tr>
<tr>
    <td>PO11</td>
    <th style="height:37px;"><?php echo $p11[1];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc2[] type=text value=></td>
</tr>
<tr>
    <td>PO12</td>
    <th style="height:37px;"><?php echo $p12[1];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc2[] type=text value=></td>
</tr>
<tr>
    <td>PSO1</td>
    <th style="height:37px;"><?php echo $ps1[1];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc2[] type=text value=></td>
</tr>
<tr>
    <td>PSO2</td>
    <th style="height:37px;"><?php echo $ps2[1];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc2[] type=text value=></td>
</tr>
<tr>
    <td>PSO3</td>
    <th style="height:37px;"><?php echo $ps3[1];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc2[] type=text value=></td>
</tr>
<tr>
     <td rowspan=16 >CO3</td>
     <tr>
    <td>PO1</td>
    <th style="height:37px;"><?php echo $p1[2];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc3[] type=text value=></td>
</tr>
<tr>
    <td>PO2</td>
    <th style="height:37px;"><?php echo $p2[2];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc3[] type=text value=></td>
</tr>
<tr>
    <td>PO3</td>
    <th style="height:37px;"><?php echo $p3[2];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc3[] type=text value=></td>
</tr>
<tr>
    <td>PO4</td>
    <th style="height:37px;"><?php echo $p4[2];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc3[] type=text value=></td>
</tr>
<tr>
    <td>PO5</td>
    <th style="height:37px;"><?php echo $p5[2];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc3[] type=text value=></td>
</tr>
<tr>
    <td>PO6</td>
    <th style="height:37px;"><?php echo $p6[2];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc3[] type=text value=></td>
</tr>
<tr>
    <td>PO7</td>
    <th style="height:37px;"><?php echo $p7[2];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc3[] type=text value=></td>
</tr>
<tr>
    <td>PO8</td>
    <th style="height:37px;"><?php echo $p8[2];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc3[] type=text value=></td>
</tr>
<tr>
    <td>PO9</td>
    <th style="height:37px;"><?php echo $p9[2];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc3[] type=text value=></td>
</tr>
<tr>
    <td>PO10</td>
    <th style="height:37px;"><?php echo $p10[2];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc3[] type=text value=></td>
</tr>
<tr>
    <td>PO11</td>
    <th style="height:37px;"><?php echo $p11[2];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc3[] type=text value=></td>
</tr>
<tr>
    <td>PO12</td>
    <th style="height:37px;"><?php echo $p12[2];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc3[] type=text value=></td>
</tr>
<tr>
    <td>PSO1</td>
    <th style="height:37px;"><?php echo $ps1[2];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc3[] type=text value=></td>
</tr>
<tr>
    <td>PSO2</td>
    <th style="height:37px;"><?php echo $ps2[2];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc3[] type=text value=></td>
</tr>
<tr>
    <td>PSO3</td>
    <th style="height:37px;"><?php echo $ps3[2];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc3[] type=text value=></td>
</tr>
<tr>
     <td rowspan=16 >CO4</td>
     <tr>
    <td>PO1</td>
    <th style="height:37px;"><?php echo $p1[3];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc4[] type=text value=></td>
</tr>
<tr>
    <td>PO2</td>
    <th style="height:37px;"><?php echo $p2[3];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc4[] type=text value=></td>
</tr>
<tr>
    <td>PO3</td>
    <th style="height:37px;"><?php echo $p3[3];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc4[] type=text value=></td>
</tr>
<tr>
    <td>PO4</td>
    <th style="height:37px;"><?php echo $p4[3];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc4[] type=text value=></td>
</tr>
<tr>
    <td>PO5</td>
    <th style="height:37px;"><?php echo $p5[3];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc4[] type=text value=></td>
</tr>
<tr>
    <td>PO6</td>
    <th style="height:37px;"><?php echo $p6[3];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc4[] type=text value=></td>
</tr>
<tr>
    <td>PO7</td>
    <th style="height:37px;"><?php echo $p7[3];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc4[] type=text value=></td>
</tr>
<tr>
    <td>PO8</td>
    <th style="height:37px;"><?php echo $p8[3];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc4[] type=text value=></td>
</tr>
<tr>
    <td>PO9</td>
    <th style="height:37px;"><?php echo $p9[3];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc4[] type=text value=></td>
</tr>
<tr>
    <td>PO10</td>
    <th style="height:37px;"><?php echo $p10[3];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc4[] type=text value=></td>
</tr>
<tr>
    <td>PO11</td>
    <th style="height:37px;"><?php echo $p11[3];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc4[] type=text value=></td>
</tr>
<tr>
    <td>PO12</td>
    <th style="height:37px;"><?php echo $p12[3];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc4[] type=text value=></td>
</tr>
<tr>
    <td>PSO1</td>
    <th style="height:37px;"><?php echo $ps1[3];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc4[] type=text value=></td>
</tr>
<tr>
    <td>PSO2</td>
    <th style="height:37px;"><?php echo $ps2[3];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc4[] type=text value=></td>
</tr>
<tr>
    <td>PSO3</td>
    <th style="height:37px;"><?php echo $ps3[3];?></th>
    <td style="padding:3px; height:36px; width:100%;"><input style="border:hidden; width:100%;" name=jc4[] type=text value=></td>
</tr>
     </table>
     </td></tr>

</tr>
  <input type=hidden name=course_cd value=<?php echo $course_cd;?>>
  <input type=hidden name=cay value=<?php echo $cay;?>>

</table>
<div class="w3-container w3-teal">
    <h3>
        <button class="w3-bar-item w3-button w3-right" type="submit" name="submit">Submit</button>
    </h3>
    
</div>
</form>
</div>
</body>
</html>
